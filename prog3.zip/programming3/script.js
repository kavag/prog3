var grassCol = "green";
var grassEatCol = "orange";
var predCol = "yellow";
var waterCol = "blue";
var fireCol = "red";

var humanCol = "purple";
var villianCol = "#282828";

var stageCol = "#acacac";
var stageCol2 = "blue";

function setup() {
    var socket = io();
    var side = 25;
    var matrix = [];

    let grassCountElement = document.getElementById('grassCount');
    let grassEaterCountElement = document.getElementById('grassEaterCount');

    let grassEaterEaterCount = document.getElementById('grassEatreCount');
    let waterCountElement = document.getElementById('waterCount');
    let fireCountElement = document.getElementById('fireCount');
    let humanColorElement = document.getElementById('humanCount');
    let villianCountElement = document.getElementById('villianCount');

    socket.on("data", drawCreatures);

    function drawCreatures(data) {
        matrix = data.matrix;

        grassCountElement.innerText = data.grassCounter;
        grassEaterCountElement.innerText = data.eaterCounter;

        grassEaterEaterCount.innerText = data.eatrCounter;
        waterCountElement.innerText = data.waterCounter;
        fireCountElement.innerText = data.fireCounter;
        humanColorElement.innerText = data.humanCounter;
        villianCountElement.innerText = data.villianCounter;

        createCanvas(matrix[0].length * side, matrix.length * side)
        background(stageCol);

        for (var i = 0; i < matrix.length; i++) {
            for (var j = 0; j < matrix[i].length; j++) {
                if (matrix[i][j] == 1) {
                    fill(grassCol);
                    rect(j * side, i * side, side, side);
                } 
                else if (matrix[i][j] == 2) {
                    fill(grassEatCol);
                    rect(j * side, i * side, side, side);
                } 
                else if (matrix[i][j] == 0) { // stage
                    fill(stageCol);
                    rect(j * side, i * side, side, side);
                }
                else if (matrix[i][j] == 3) {
                    fill(fireCol);
                    rect(j * side, i * side, side, side);
                } 
                else if (matrix[i][j] == 4) {
                    fill(waterCol);
                    rect(j * side, i * side, side, side);
                } 
                else if (matrix[i][j] == 5) {
                    fill(predCol);
                    rect(j * side, i * side, side, side);
                }
                else if (matrix[i][j] == 6) {
                    fill(humanCol);
                    rect(j * side, i * side, side, side);
                }
                else if (matrix[i][j] == 7) {
                    fill(villianCol);
                    rect(j * side, i * side, side, side);
                }
            }
        }
    }
}